function cost = cost(N)
%COST Summary of this function goes here
%   Detailed explanation goes here
cost = sum((N-[50000000000 50000000000]).^2)*0.000000001;
end

